export interface RegisterUser {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: "Customer" | "Seller" | "Admin";
}